import { useState } from "react";
import { CheckCircle2, Loader2, Phone } from "lucide-react";
import { SITE } from "@/lib/siteConfig";
import { cn } from "@/lib/utils";

/**
 * Case-review form.
 *
 * Posts JSON to the EXISTING live endpoint /api/submit-form.php, which inserts into the
 * `leads` table (first_name, last_name, phone, email, case_description, page_url) in
 * laleona_dashboard and emails the firm. Field names below must stay exactly as they are:
 *   firstName, lastName, phone (required) · email, caseDescription, pageUrl (optional)
 * The endpoint answers {"status":"success"} or {"status":"error","message":"..."}.
 */

type LeadFormProps = {
  /** Unique id per placement so form submissions can be told apart (e.g. "lead-form-hero") */
  formId: string;
  /** "dark" for black sections, "light" for white/cream sections */
  tone?: "dark" | "light";
  /** "stacked" = one column card, "wide" = multi-column strip */
  layout?: "stacked" | "wide";
  submitLabel?: string;
  className?: string;
};

type FormState = {
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  caseDescription: string;
};

const EMPTY: FormState = { firstName: "", lastName: "", phone: "", email: "", caseDescription: "" };

const LeadForm = ({
  formId,
  tone = "dark",
  layout = "stacked",
  submitLabel = "Get My Free Case Review",
  className,
}: LeadFormProps) => {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [honeypot, setHoneypot] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  const dark = tone === "dark";

  const update = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Bots fill hidden fields; real people never see this one. Pretend it worked and send nothing.
    if (honeypot) {
      setStatus("success");
      return;
    }

    setStatus("sending");
    setErrorMsg("");

    try {
      const res = await fetch("/api/submit-form.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName: form.firstName.trim(),
          lastName: form.lastName.trim(),
          phone: form.phone.trim(),
          email: form.email.trim(),
          caseDescription: form.caseDescription.trim(),
          pageUrl: window.location.href,
        }),
      });

      const data = await res.json().catch(() => null);

      if (data && data.status === "success") {
        setStatus("success");
        setForm(EMPTY);
      } else {
        setStatus("error");
        setErrorMsg(
          (data && data.message) || `Something went wrong. Please call us at ${SITE.vanityPhone}.`
        );
      }
    } catch {
      setStatus("error");
      setErrorMsg(`We couldn't send your request. Please call us at ${SITE.vanityPhone}.`);
    }
  };

  const label = cn(
    "mb-1.5 block text-xs font-bold uppercase tracking-[0.14em]",
    dark ? "text-white/80" : "text-brand-ink/80"
  );
  const field = cn(
    "block w-full rounded-md border px-4 py-3 text-base outline-none transition-colors",
    "focus:border-brand-red focus:ring-2 focus:ring-brand-red/30",
    dark
      ? "border-white/15 bg-white/[0.06] text-white placeholder:text-white/40"
      : "border-brand-ink/15 bg-white text-brand-ink placeholder:text-brand-ink/40"
  );

  if (status === "success") {
    return (
      <div
        className={cn(
          "flex flex-col items-center rounded-lg px-6 py-10 text-center",
          dark ? "bg-white/[0.04] text-white" : "bg-white text-brand-ink",
          className
        )}
        role="status"
        aria-live="polite"
      >
        <CheckCircle2 className="h-12 w-12 text-brand-red" aria-hidden="true" />
        <h3 className="mt-4 text-2xl font-bold">Thank You</h3>
        <p className={cn("mt-2 max-w-sm text-base", dark ? "text-white/75" : "text-brand-ink/70")}>
          Your case review request was received. Our office will contact you shortly.
          If it's urgent, call us now.
        </p>
        <a href={SITE.phoneHref} className="btn-red mt-6">
          <Phone className="h-4 w-4" aria-hidden="true" />
          Call {SITE.vanityPhone}
        </a>
      </div>
    );
  }

  const wide = layout === "wide";

  return (
    <form id={formId} onSubmit={handleSubmit} className={cn("w-full", className)}>
      {/* Honeypot (hidden from people and screen readers) */}
      <div className="absolute -left-[9999px] h-px w-px overflow-hidden" aria-hidden="true">
        <label htmlFor={`${formId}-website`}>Website</label>
        <input
          id={`${formId}-website`}
          type="text"
          name="website"
          tabIndex={-1}
          autoComplete="off"
          value={honeypot}
          onChange={(e) => setHoneypot(e.target.value)}
        />
      </div>

      <div className={cn("grid gap-4", wide ? "sm:grid-cols-2 lg:grid-cols-4" : "sm:grid-cols-2")}>
        <div>
          <label htmlFor={`${formId}-firstName`} className={label}>
            First Name <span className="text-brand-red">*</span>
          </label>
          <input
            id={`${formId}-firstName`}
            name="firstName"
            autoComplete="given-name"
            required
            value={form.firstName}
            onChange={update}
            className={field}
          />
        </div>
        <div>
          <label htmlFor={`${formId}-lastName`} className={label}>
            Last Name <span className="text-brand-red">*</span>
          </label>
          <input
            id={`${formId}-lastName`}
            name="lastName"
            autoComplete="family-name"
            required
            value={form.lastName}
            onChange={update}
            className={field}
          />
        </div>
        <div>
          <label htmlFor={`${formId}-phone`} className={label}>
            Phone <span className="text-brand-red">*</span>
          </label>
          <input
            id={`${formId}-phone`}
            name="phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel"
            required
            value={form.phone}
            onChange={update}
            className={field}
          />
        </div>
        <div>
          <label htmlFor={`${formId}-email`} className={label}>
            Email
          </label>
          <input
            id={`${formId}-email`}
            name="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={update}
            className={field}
          />
        </div>
        <div className={cn(wide ? "sm:col-span-2 lg:col-span-4" : "sm:col-span-2")}>
          <label htmlFor={`${formId}-caseDescription`} className={label}>
            What happened?
          </label>
          <textarea
            id={`${formId}-caseDescription`}
            name="caseDescription"
            rows={wide ? 2 : 3}
            value={form.caseDescription}
            onChange={update}
            className={cn(field, "resize-none")}
            placeholder="Briefly describe your accident or injury"
          />
        </div>
      </div>

      {status === "error" && (
        <p className="mt-4 rounded-md border border-brand-red/40 bg-brand-red/10 px-4 py-3 text-sm font-semibold text-brand-red" role="alert">
          {errorMsg}
        </p>
      )}

      <div className={cn("mt-5 flex flex-col gap-4", wide && "lg:flex-row lg:items-center lg:justify-between")}>
        <button type="submit" className={cn("btn-red w-full", wide && "lg:w-auto lg:min-w-[280px]")} disabled={status === "sending"}>
          {status === "sending" ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              Sending…
            </>
          ) : (
            submitLabel
          )}
        </button>
        <p className={cn("text-xs leading-relaxed", dark ? "text-white/50" : "text-brand-ink/55", wide && "lg:max-w-md")}>
          Free and confidential. Submitting this form does not create an attorney-client relationship.
        </p>
      </div>
    </form>
  );
};

export default LeadForm;
