import LeadForm from "@/components/LeadForm";
import { SITE } from "@/lib/siteConfig";

/** White form card that overlaps the bottom of the hero. */
const CaseReviewStrip = () => (
  <section id="case-review" className="relative bg-brand-cream px-4 pb-20 pt-10 sm:px-6 lg:pt-0">
    <div className="relative z-10 mx-auto -mt-px max-w-6xl lg:-mt-24">
      <div className="overflow-hidden rounded-lg border-t-4 border-brand-red bg-white shadow-[0_30px_80px_-20px_rgba(0,0,0,0.35)]">
        <div className="grid lg:grid-cols-12">
          <div className="bg-brand-ink px-8 py-10 text-white lg:col-span-4 lg:px-10">
            <p className="eyebrow">Free & Confidential</p>
            <h2 className="mt-4 text-3xl font-bold leading-tight">Free Case Review</h2>
            <p className="mt-4 text-base leading-relaxed text-white/70">
              Tell us what happened. Our office will review your case and call you back — at no cost to you.
            </p>
            <div className="mt-8 border-t border-white/10 pt-6">
              <p className="text-sm font-semibold uppercase tracking-[0.16em] text-white/50">Prefer to talk?</p>
              <a href={SITE.phoneHref} className="mt-1 block font-cinzel text-2xl font-black tracking-wide text-brand-red hover:text-white">
                {SITE.vanityPhone}
              </a>
              <a href={SITE.spanishPhoneHref} className="mt-1 block text-[15px] text-white/70 hover:text-white">
                Español: {SITE.spanishPhoneDisplay}
              </a>
            </div>
          </div>
          <div className="px-6 py-8 sm:px-8 lg:col-span-8 lg:px-10 lg:py-10">
            <LeadForm formId="lead-form-home-case-review" tone="light" layout="stacked" />
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default CaseReviewStrip;
