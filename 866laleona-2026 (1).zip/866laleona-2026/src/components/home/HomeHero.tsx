import { Check, Phone } from "lucide-react";
import { SITE } from "@/lib/siteConfig";

const TRUST_POINTS = ["Free Consultation", "Hablamos Español", "Born & Raised in the Valley"];

const HomeHero = () => (
  <section className="relative isolate overflow-hidden bg-black text-white">
    {/* Background: red glow + seal watermark */}
    <div
      className="absolute inset-0 -z-10"
      aria-hidden="true"
      style={{
        background:
          "radial-gradient(ellipse 60% 70% at 78% 45%, rgba(214,26,32,0.28) 0%, rgba(214,26,32,0.08) 40%, rgba(0,0,0,0) 70%)",
      }}
    />
    <img
      src="/images/seal-white.png"
      alt=""
      aria-hidden="true"
      className="pointer-events-none absolute -left-40 top-1/2 -z-10 hidden w-[760px] -translate-y-1/2 opacity-[0.035] lg:block"
    />

    <div className="mx-auto grid max-w-7xl items-end gap-6 px-6 pt-12 lg:grid-cols-12 lg:gap-10 lg:pt-16">
      {/* Copy */}
      <div className="animate-fade-up pb-12 lg:col-span-7 lg:pb-36">
        <h1 className="font-cinzel">
          <span className="eyebrow !font-sans">Brownsville Personal Injury Attorney</span>
          <span className="mt-6 block text-[2.6rem] font-black leading-[1.02] sm:text-6xl xl:text-[5.25rem]">
            Protecting
            <span className="block text-brand-red">Your Rights</span>
          </span>
          <span className="mt-4 block text-xl font-bold tracking-[0.12em] text-white/85 sm:text-2xl xl:text-[1.9rem]">
            Every Step of the Way
          </span>
        </h1>

        <p className="mt-7 max-w-xl text-lg leading-relaxed text-white/75 sm:text-xl">
          When an accident turns your life upside down, {SITE.attorneyName} — La Leona del Valle —
          fights for the compensation you and your family deserve. Car, truck, workplace and oil field
          injuries across the Rio Grande Valley.
        </p>

        <div className="mt-9 flex flex-col gap-4 sm:flex-row">
          <a href={SITE.phoneHref} className="btn-red !py-4 !text-lg">
            <Phone className="h-5 w-5" aria-hidden="true" />
            Call {SITE.vanityPhone}
          </a>
          <a href="#case-review" className="btn-outline-light !py-4 !text-lg">
            Free Case Review
          </a>
        </div>

        <ul className="mt-10 flex flex-wrap gap-x-7 gap-y-3">
          {TRUST_POINTS.map((point) => (
            <li key={point} className="flex items-center gap-2 text-[15px] font-semibold text-white/85">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-red/20">
                <Check className="h-3.5 w-3.5 text-brand-red" strokeWidth={3} aria-hidden="true" />
              </span>
              {point}
            </li>
          ))}
        </ul>
      </div>

      {/* Photo */}
      <div className="relative mx-auto w-full max-w-md lg:col-span-5 lg:max-w-none">
        <img
          src="/images/liz-hero.webp"
          alt={`Attorney ${SITE.attorneyName} in her Brownsville office`}
          width={1000}
          height={1338}
          className="relative z-0 mx-auto block w-full max-w-[520px] select-none"
          draggable={false}
        />
        {/* Fade the photo into the next section */}
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black to-transparent" aria-hidden="true" />
        <div className="absolute bottom-8 left-1/2 w-max -translate-x-1/2 border-l-4 border-brand-red bg-black/80 px-5 py-3 backdrop-blur-sm lg:bottom-36 lg:left-auto lg:right-0 lg:translate-x-0">
          <p className="font-cinzel text-lg font-bold tracking-wide">{SITE.attorneyName}</p>
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-white/60">Attorney at Law</p>
        </div>
      </div>
    </div>
  </section>
);

export default HomeHero;
